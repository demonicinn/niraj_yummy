<footer class="app-footer">
    <strong>
        Copyright &copy; 2024-{{ date('Y') }}&nbsp;
        <a target="_blank" href="javascript:void(0)" class="text-decoration-none">{{ env('APP_NAME') }}</a>.
    </strong>
    All rights reserved.
</footer>