<form>
    <div class="input-group">
        <input type="search" name="search" class="form-control form-control-sm" placeholder="Search"
            value="{{ request()->search }}">
        <button type="submit" class="input-group-text"><i class="bi bi-search"></i></button>
    </div>
</form>