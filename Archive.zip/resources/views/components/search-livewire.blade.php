<div class="input-group">
    <input type="search" class="form-control form-control-sm" placeholder="Search"
        wire:model.live.debounce.1000ms="search">
    <span class="input-group-text"><i class="bi bi-search"></i></span>
</div>