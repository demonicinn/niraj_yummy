<?php $__env->startSection('title', 'Restaurants'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card mb-4">
        <div class="card-header">

            <div class="row">
                <div class="col-4">
                    <?php echo $__env->make('components.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>


        </div>
        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Name</th>
                        <th>Type</th>
                        <th>Capacity</th>
                        <th>website_link</th>
                        <th>Rating</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $hasUser = '';
                        if(request()->user){
                            $hasUser = '?user='.request()->user;
                        }
                    ?>
                    <?php $__currentLoopData = $restaurantsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($restaurantsData->firstItem() + $loop->index); ?></td>
                            <td><a href="<?php echo e(route('ab.restaurants.show', $data->id)); ?>"><?php echo e($data->name); ?></a></td>
                            <td><?php echo e($data->type); ?></td>
                            <td><?php echo e($data->capacity); ?></td>
                            <td>
                                <?php if($data->website_link): ?>
                                <a href="<?php echo e($data->website_link); ?>">Link</a>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->rating); ?></td>
                            <td>
                                <a href="<?php echo e(route('ab.restaurants.show', $data->id)); ?><?php echo e($hasUser); ?>"
                                    class="btn btn-primary btn-sm">Details</a>

                                <a href="<?php echo e(route('ab.restaurants.reviews', $data->id)); ?><?php echo e($hasUser); ?>"
                                        class="btn btn-success btn-sm">Reviews</a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

        <div class="card-footer clearfix">
            <?php echo e($restaurantsData->links()); ?>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/restaurants/index.blade.php ENDPATH**/ ?>