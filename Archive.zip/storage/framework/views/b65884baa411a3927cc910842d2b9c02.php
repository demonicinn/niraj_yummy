<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card mb-4">
        <div class="card-header">

            <div class="row">
                <div class="col-4">
                    <?php echo $__env->make('components.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>


        </div>
        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>DOB</th>
                        <th>Number</th>
                        <th>Status</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($users->firstItem() + $loop->index); ?></td>
                            <td>
                                <?php if($data->image_path): ?>
                                <img src="<?php echo e($data->image_path); ?>" width="100" height="75">
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($data->name); ?></td>
                            <td><?php echo e($data->email); ?></td>
                            <td><?php echo e($data->dob); ?></td>
                            <td><?php echo e($data->number); ?></td>
                            <td><?php echo e(statusValue($data->status)); ?></td>
                            <td>
                                <a href="<?php echo e(route('ab.users.show', $data->id)); ?>"
                                    class="btn btn-primary btn-sm">Details</a>

                                    <a href="<?php echo e(route('ab.users.edit', $data->id)); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>

                                <a data-method="Delete" data-confirm="Are you sure to delete?" href="<?php echo e(route('ab.users.delete', $data->id)); ?>"
                                        class="btn btn-danger btn-sm">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

        <div class="card-footer clearfix">
            <?php echo e($users->links()); ?>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/users/index.blade.php ENDPATH**/ ?>