<div class="col-12">
    <div class="card card-primary card-outline mb-4">
        <div class="card-header">
            <div class="card-title"><?php echo e($title); ?></div>
        </div>
        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Description</th>
                        <th>Rating</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($app->name); ?></td>
                            <td>$<?php echo e($app->price); ?></td>
                            <td><?php echo e($app->description); ?></td>
                            <td><?php echo e($app->rating); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/restaurants/menu.blade.php ENDPATH**/ ?>