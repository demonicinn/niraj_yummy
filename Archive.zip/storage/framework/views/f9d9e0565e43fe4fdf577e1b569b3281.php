<?php $__env->startSection('title', 'User Details'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">User Details</div>
            <div class="float-end">
                <a href="<?php echo e(route('ab.users')); ?>" class="btn btn-warning btn-sm"><i
                    class="nav-icon bi bi-arrow-left"></i></a>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">
                    <div class="col-12">
                        <div class="text-truncate"><b>Name:</b> <?php echo e($user->name); ?></div>
                        <div class="text-truncate"><b>Email:</b> <?php echo e($user->email); ?></div>
                        <div class="text-truncate"><b>DOB:</b> <?php echo e($user->dob); ?></div>
                        <div class="text-truncate"><b>Number:</b> <?php echo e($user->number); ?></div>
                        <div class="text-truncate"><b>Status:</b> <?php echo e(statusValue($user->status)); ?></div>
                        <div class="text-truncate"><b>Image:</b> 
                            <?php if($user->image): ?>
                            </br>
                            <img src="<?php echo e($user->image_path); ?>" width="200" height="200">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</div>

<?php if($user->about): ?>
<?php $about = $user->about; ?>
<div class="col-12">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">About Us</div>
        </div>

        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">
                    <div class="col-12">
                        <div class="text-truncate"><b>Name:</b> <?php echo e($about->name); ?></div>
                        <div class="text-truncate"><b>Relation:</b> <?php echo e($about->relation); ?></div>
                        <div class="text-truncate"><b>DOB:</b> <?php echo e($about->dob); ?></div>
                        <div class="text-truncate"><b>FB Username:</b> <?php echo e($about->fb_username); ?></div>
                        <div class="text-truncate"><b>Description:</b> <?php echo $about->description; ?></div>
                        <div class="text-truncate"><b>Image:</b> 
                            <?php if($about->image): ?>
                            </br>
                            <img src="<?php echo e($about->image_path); ?>" width="200" height="200">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/ab/users/show.blade.php ENDPATH**/ ?>