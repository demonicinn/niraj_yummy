<form>
    <div class="input-group">
        <input type="search" name="search" class="form-control form-control-sm" placeholder="Search"
            value="<?php echo e(request()->search); ?>">
        <button type="submit" class="input-group-text"><i class="bi bi-search"></i></button>
    </div>
</form><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/components/search.blade.php ENDPATH**/ ?>