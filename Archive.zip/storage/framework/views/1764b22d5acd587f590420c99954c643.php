<footer class="app-footer">
    <strong>
        Copyright &copy; 2024-<?php echo e(date('Y')); ?>&nbsp;
        <a target="_blank" href="javascript:void(0)" class="text-decoration-none"><?php echo e(env('APP_NAME')); ?></a>.
    </strong>
    All rights reserved.
</footer><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/layouts/includes_ab/footer.blade.php ENDPATH**/ ?>