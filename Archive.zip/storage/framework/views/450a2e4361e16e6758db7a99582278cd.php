<?php $__env->startSection('title', 'Restaurant Details'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $hasUser = '';
    if(request()->user){
        $hasUser = '?user='.request()->user;
    }
?>
<div class="col-12">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">Restaurant Details</div>
            <div class="float-end">

                <a href="<?php echo e(route('ab.restaurants.reviews', $restaurant->id)); ?><?php echo e($hasUser); ?>"
                    class="btn btn-success btn-sm">Reviews</a>

                <a href="<?php echo e(route('ab.restaurants')); ?>" class="btn btn-warning btn-sm"><i
                    class="nav-icon bi bi-arrow-left"></i></a>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">

                    <div class="col-12">
                        <div class="text-truncate"><b>Name:</b> <?php echo e($restaurant->name); ?></div>
                        <div class="text-truncate"><b>Description:</b> <?php echo e($restaurant->description); ?></div>
                        <div class="text-truncate"><b>Type:</b> <?php echo e($restaurant->type); ?></div>
                        <div class="text-truncate"><b>Capacity:</b> <?php echo e($restaurant->capacity); ?></div>
                        <div class="text-truncate"><b>Latitue:</b> <?php echo e($restaurant->latitue); ?></div>
                        <div class="text-truncate"><b>Longitude:</b> <?php echo e($restaurant->longitude); ?></div>
                        <div class="text-truncate"><b>Booking Mode:</b> <?php echo e($restaurant->booking_mode); ?></div>
                        <div class="text-truncate"><b>Website Link:</b> 
                            <?php if($restaurant->website_link): ?>
                            <a target="_blank" href="<?php echo e($restaurant->website_link); ?>"><?php echo e($restaurant->website_link); ?></a>
                            <?php endif; ?>
                        </div>
                        <div class="text-truncate"><b>Rating:</b> <?php echo e($restaurant->rating); ?></div>
                        <div class="text-truncate"><b>Total User Rating:</b> <?php echo e($restaurant->user_ratings_total); ?></div>
                        <div class="text-truncate"><b>Address:</b> <?php echo e($restaurant->formatted_address); ?></div>
                        <div class="text-truncate"><b>Phone Number:</b> <?php echo e($restaurant->formatted_phone_number); ?></div>
                    </div>
                </div>
            </div>
        </div>


        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">
                    <div class="col-12">
                        <h4>Editorial Summary:</h4>
                        <div class="text-truncate"><?php echo e($restaurant->editorial_summary->overview); ?></div>
                    </div>
                </div>
            </div>
        </div>


        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">
                    <div class="col-12">
                        <h4>Opening Hours:</h4>
                        <?php $__currentLoopData = $restaurant->opening_hours->weekday_text; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-truncate"><?php echo e($hours); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</div>




<?php if($restaurant->restaurantMenus): ?>
<?php $menu = $restaurant->restaurantMenus; ?>
<h3>Menus</h3>

<?php echo $__env->make('ab.restaurants.menu', ['data'=>$menu->appetizers, 'title'=>'Appetizers'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('ab.restaurants.menu', ['data'=>$menu->entree, 'title'=>'Entree'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('ab.restaurants.menu', ['data'=>$menu->desserts, 'title'=>'Desserts'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('ab.restaurants.menu', ['data'=>$menu->drinks, 'title'=>'Drinks'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/restaurants/show.blade.php ENDPATH**/ ?>