<div class="row">
  
    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-primary">
        <div class="inner">
          <h3><?php echo e(@$data['restaurantsCount']); ?></h3>
          <p>Total Restaurants</p>
        </div>
        <a href="<?php echo e(route('ab.restaurants')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>


    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-danger">
        <div class="inner">
          <h3><?php echo e(@$data['usersCount']); ?></h3>
          <p>Total Users</p>
        </div>
        <a href="<?php echo e(route('ab.users')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>



  </div><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/dashboard/total.blade.php ENDPATH**/ ?>