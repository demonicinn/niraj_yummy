<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>


<div class="app-content">
    <div class="container-fluid">

    <?php echo $__env->make('ab.dashboard.total', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>
</div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/ab/dashboard/index.blade.php ENDPATH**/ ?>