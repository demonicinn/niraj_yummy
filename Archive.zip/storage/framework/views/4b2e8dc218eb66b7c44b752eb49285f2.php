<div class="row">
  
    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-primary">
        <div class="inner">
          <h3><?php echo e(@$data['podcastCount']); ?></h3>
          <p>Total Podcast</p>
        </div>
        <a href="<?php echo e(route('ab.home.podcast')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>


    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-success">
        <div class="inner">
          <h3><?php echo e(@$data['livestreamCount']); ?></h3>
          <p>Total Livestream</p>
        </div>
        <a href="<?php echo e(route('ab.home.livestream')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>
    
    
    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-warning">
        <div class="inner">
          <h3><?php echo e(@$data['blogsCount']); ?></h3>
          <p>Total Blogs</p>
        </div>
        <a href="<?php echo e(route('ab.home.blogs')); ?>" class="small-box-footer link-dark link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>
    

    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-danger">
        <div class="inner">
          <h3><?php echo e(@$data['bibleCount']); ?></h3>
          <p>Total Bible</p>
        </div>
        <a href="<?php echo e(route('ab.bible')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>

    
    <div class="col-lg-3 col-6">
      <div class="small-box text-bg-danger">
        <div class="inner">
          <h3><?php echo e(@$data['usersCount']); ?></h3>
          <p>Total Users</p>
        </div>
        <a href="<?php echo e(route('ab.users')); ?>" class="small-box-footer link-light link-underline-opacity-0 link-underline-opacity-50-hover">
          More info <i class="bi bi-link-45deg"></i>
        </a>
      </div>
    </div>



  </div><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/ab/dashboard/total.blade.php ENDPATH**/ ?>