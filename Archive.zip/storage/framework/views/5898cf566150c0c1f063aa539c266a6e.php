<?php $__env->startSection('title', 'User Details'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-12">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">User Details</div>
            <div class="float-end">

                <a href="<?php echo e(route('ab.restaurants')); ?>?user=<?php echo e($user->id); ?>" class="btn btn-success btn-sm">Restaurants</a>
                
                <a href="<?php echo e(route('ab.users.edit', $user->id)); ?>"
                    class="btn btn-warning btn-sm">Edit</a>

                <a data-method="Delete" data-confirm="Are you sure to delete?" href="<?php echo e(route('ab.users.delete', $user->id)); ?>"
                    class="btn btn-danger btn-sm">Delete</a>

                <a href="<?php echo e(route('ab.users')); ?>" class="btn btn-warning btn-sm"><i
                    class="nav-icon bi bi-arrow-left"></i></a>
            </div>
        </div>

        <div class="card-body p-0">
            <div class="px-2">
                <div class="d-flex border-top py-2 px-1">
                    <div class="col-12">
                        <div class="text-truncate"><b>Name:</b> <?php echo e($user->name); ?></div>
                        <div class="text-truncate"><b>Email:</b> <?php echo e($user->email); ?></div>
                        <div class="text-truncate"><b>DOB:</b> <?php echo e($user->dob); ?></div>
                        <div class="text-truncate"><b>Number:</b> <?php echo e($user->number); ?></div>
                        <div class="text-truncate"><b>Status:</b> <?php echo e(statusValue($user->status)); ?></div>
                        <div class="text-truncate"><b>Image:</b> 
                            <?php if($user->image_path): ?>
                            </br>
                            <img src="<?php echo e($user->image_path); ?>" width="200" height="200">
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
    </div>
</div>

<?php if($user->preferences): ?>
<?php $preferences = $user->preferences->data; ?>
<div class="col-12">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">Preferences</div>
        </div>

        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>Key</th>
                        <th>Value</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $preferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $preference): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($preference->key); ?></td>
                            <td><?php echo e($preference->value); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

        
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/users/show.blade.php ENDPATH**/ ?>