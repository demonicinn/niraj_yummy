<?php $__env->startSection('title', 'Edit User'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-6">
    <div class="card card-primary card-outline mb-4">

        <div class="card-header">
            <div class="card-title">Edit User</div>
            <a href="<?php echo e(route('ab.users')); ?>" class="btn btn-warning btn-sm float-end"><i
                    class="nav-icon bi bi-arrow-left"></i></a>
        </div>

        <?php echo e(html()->model($user)->form('PATCH', route('ab.users.edit', $user->id))->acceptsFiles()->open()); ?>


        <?php echo $__env->make('ab.users.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php echo e(html()->form()->close()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/users/edit.blade.php ENDPATH**/ ?>