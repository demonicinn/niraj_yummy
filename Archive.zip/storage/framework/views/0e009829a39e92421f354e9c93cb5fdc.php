<?php
    $segment2 = request()->segment(2);
    $segment3 = request()->segment(3);
    pagesTitle();

?>

<aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a href="<?php echo e(route('ab')); ?>" class="brand-link">
            <span class="brand-text fw-light"><?php echo e($app); ?></span>
        </a>
    </div>

    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.dashboard')); ?>"
                        class="nav-link<?php echo e($segment2=='' || $segment2=='dashboard' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-palette"></i>
                        <p>Dashboard</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.video')); ?>"
                        class="nav-link<?php echo e($segment2=='video' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-camera-video"></i>
                        <p>Video URL</p>
                    </a>
                </li>

                <li class="nav-item<?php echo e($segment2=='home' ? ' menu-open':''); ?>">
                    <a href="javascript:void(0)" class="nav-link">
                        <i class="nav-icon bi bi-cloud"></i>
                        <p>
                            Home
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>


                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.home.podcast')); ?>" class="nav-link<?php echo e($segment3=='podcast' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('home', 'podcast')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.home.livestream')); ?>" class="nav-link<?php echo e($segment3=='livestream' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('home', 'livestream')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.home.blogs')); ?>" class="nav-link<?php echo e($segment3=='blogs' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('home', 'blogs')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.home.courses.category')); ?>" class="nav-link<?php echo e($segment3=='courses' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('home', 'courses')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.home.audio')); ?>" class="nav-link<?php echo e($segment3=='audio' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('home', 'audio')); ?></p>
                            </a>
                        </li>
                        
                    </ul>
                </li>


                <li class="nav-item<?php echo e($segment2=='media' ? ' menu-open':''); ?>">
                    <a href="javascript:void(0)" class="nav-link">
                        <i class="nav-icon bi bi-film"></i>
                        <p>
                            Media
                            <i class="nav-arrow bi bi-chevron-right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.media.podcast.category')); ?>" class="nav-link<?php echo e($segment3=='podcast' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('media', 'podcast')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.media.livestream.category')); ?>" class="nav-link<?php echo e($segment3=='livestream' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('media', 'livestream')); ?></p>
                            </a>
                        </li>

                        <li class="nav-item">
                            <a href="<?php echo e(route('ab.media.audio.category')); ?>" class="nav-link<?php echo e($segment3=='audio' ? ' active':''); ?>">
                                <i class="nav-icon bi bi-circle"></i>
                                <p><?php echo e(getTitle('media', 'audio')); ?></p>
                            </a>
                        </li>
                        
                    </ul>
                </li>


                <li class="nav-item">
                    <a href="<?php echo e(route('ab.bible')); ?>"
                        class="nav-link<?php echo e($segment2=='bible' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-book"></i>
                        <p>Bible</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.banner')); ?>"
                        class="nav-link<?php echo e($segment2=='banner' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-book"></i>
                        <p>Banner Images</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.users')); ?>"
                        class="nav-link<?php echo e($segment2=='users' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-people"></i>
                        <p>Users</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.categories')); ?>"
                        class="nav-link<?php echo e($segment2=='categories' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-bookmark"></i>
                        <p>Categories</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="<?php echo e(route('ab.dashboard')); ?>"
                        class="nav-link<?php echo e($segment2=='payments' ? ' active':''); ?>">
                        <i class="nav-icon bi bi-book"></i>
                        <p>Payments</p>
                    </a>
                </li>

                

            </ul>
        </nav>
    </div>
</aside>
<?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_new/resources/views/layouts/includes_ab/sidebar.blade.php ENDPATH**/ ?>