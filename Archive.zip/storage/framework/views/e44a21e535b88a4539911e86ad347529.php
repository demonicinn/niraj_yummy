<?php if($message = Session::get('success')): ?>
    <div class="alert callout callout-success">
        <?php echo $message; ?>

    </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert callout callout-danger">
        <?php echo $message; ?>

    </div>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
    <div class="alert callout callout-warning">
        <?php echo $message; ?>

    </div>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
    <div class="alert callout callout-info">
        <?php echo $message; ?>

    </div>
<?php endif; ?>
<?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/layouts/includes_ab/alerts.blade.php ENDPATH**/ ?>