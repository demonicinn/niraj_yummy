<?php
    $submitButton = 'Create';
    if(request()->segment(3) != 'create'){
        $submitButton = 'Update';
    }
?>



<div class="card-body">
    <div class="mb-3">
        <label class="form-label">First Name <sm>*</sm></label>
        <?php echo e(html()->text('first_name')->class('form-control'. ($errors->has('first_name') ? ' is-invalid' : ''))->placeholder('')); ?>

        <?php echo $errors->first('first_name', '<span class="help-block mb-1">:message</span>'); ?>

    </div>
    <div class="mb-3">
        <label class="form-label">Last Name <sm>*</sm></label>
        <?php echo e(html()->text('last_name')->class('form-control'. ($errors->has('last_name') ? ' is-invalid' : ''))->placeholder('')); ?>

        <?php echo $errors->first('last_name', '<span class="help-block mb-1">:message</span>'); ?>

    </div>
    <div class="mb-3">
        <label class="form-label">Email <sm>*</sm></label>
        <?php echo e(html()->email('email')->class('form-control'. ($errors->has('email') ? ' is-invalid' : ''))->placeholder('')); ?>

        <?php echo $errors->first('email', '<span class="help-block mb-1">:message</span>'); ?>

    </div>


    <div class="mb-3">
        <label class="form-label">Password</label>
        <?php echo e(html()->password('password')->class('form-control'. ($errors->has('password') ? ' is-invalid' : ''))); ?>

        <?php echo $errors->first('password', '<span class="help-block mb-1">:message</span>'); ?>

    </div>
    <div class="mb-3">
        <label class="form-label">Password Confirmation</label>
        <?php echo e(html()->password('password_confirmation')->class('form-control'. ($errors->has('password_confirmation') ? ' is-invalid' : ''))); ?>

        <?php echo $errors->first('password_confirmation', '<span class="help-block mb-1">:message</span>'); ?>

    </div>


    <div class="mb-3">
        <label class="form-label">DOB <sm>*</sm></label>
        <?php echo e(html()->date('dob')->class('form-control'. ($errors->has('dob') ? ' is-invalid' : ''))->placeholder('')); ?>

        <?php echo $errors->first('dob', '<span class="help-block mb-1">:message</span>'); ?>

    </div>
    <div class="mb-3">
        <label class="form-label">Number <sm>*</sm></label>
        <?php echo e(html()->number('number')->class('form-control'. ($errors->has('number') ? ' is-invalid' : ''))->placeholder('')); ?>

        <?php echo $errors->first('number', '<span class="help-block mb-1">:message</span>'); ?>

    </div>

    <div class="mb-3">
        <label class="form-label">Image </label>

        <?php if(isset($user) && $user->image): ?>
            </br>
            <img src="<?php echo e($user->image_path); ?>" height="150" width="150">
        <?php endif; ?>
        <?php echo e(html()->file('image')->class('form-control'. ($errors->has('image') ? ' is-invalid' : ''))->accept(env('IMAGE_MIME'))); ?>

        <?php echo $errors->first('image', '<span class="help-block mb-1">:message</span>'); ?>

    </div>


    <div class="mb-3">
        <label class="form-label">Status <sm>*</sm></label>
        <?php echo e(html()->select('status')->class('form-control'. ($errors->has('status') ? ' is-invalid' : ''))->options(statusArray())); ?>

        <?php echo $errors->first('status', '<span class="help-block mb-1">:message</span>'); ?>

    </div>

</div>
<div class="card-footer">
    <button type="submit" class="btn btn-primary"><?php echo e($submitButton); ?></button>
</div>

<?php $__env->startSection('script'); ?>
<script>
    function deleteAttachment(id){
        if(confirm("Are you sure you want to delete this?")){
            $('.btn-group.attach'+id).remove();
        }
        else{
            return false;
        }
    }
</script>
<?php $__env->stopSection(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/users/form.blade.php ENDPATH**/ ?>