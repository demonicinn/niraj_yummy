<?php $__env->startSection('title', 'Restaurant Reviews'); ?>
<?php $__env->startSection('content'); ?>

<div class="col-md-12">
    <div class="card mb-4">
        <div class="card-header">

            <div class="row">
                <div class="col-4">
                    <?php echo $__env->make('components.search', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            </div>


        </div>
        <div class="card-body p-0">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th style="width: 10px">#</th>
                        <th>User</th>
                        <th>Review</th>
                        <th>Rating</th>
                        <th>Image</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__currentLoopData = $restaurantReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="align-middle">
                            <td><?php echo e($restaurantReviews->firstItem() + $loop->index); ?></td>
                            <td><a href="<?php echo e(route('ab.users.show', $data->user->id)); ?>"><?php echo e($data->user->name); ?></a></td>
                            <td><?php echo $data->review; ?></td>
                            <td><?php echo e($data->rating); ?></td>
                            <td>
                                <?php if($data->image_path): ?>
                                <img src="<?php echo e($data->image_path); ?>" width="100" height="75">
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>

        <div class="card-footer clearfix">
            <?php echo e($restaurantReviews->links()); ?>

        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.ab', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/gurpreetsingh/Desktop/Git/laravel/niraj_yummy/resources/views/ab/restaurants/reviews.blade.php ENDPATH**/ ?>